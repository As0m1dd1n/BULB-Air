# BULB-Air data pack, everything up to 31 Dec 2021

## Files
- omi_no2_daily_17boxes_2004-2021.csv: daily tropospheric NO2 (10^15 molec/cm2), 6x6-cell (1.5°) box mean, 14 regions + 3 desert background boxes (bg_*). Empty = no valid retrieval (cloud, row anomaly, winter snow, orbit gaps). 2004-10-01 to 2021-12-31, 6301 days.
- omi_no2_monthly_mean_2004-2021.csv, omi_no2_monthly_valid_days_2004-2021.csv, omi_no2_annual_mean_2004-2021.csv: aggregates, plus the count of valid days behind each month.
- omi_data_coverage_by_year.csv: share of days with a valid value, per box and year.
- omi_no2_seasonal_anomaly_values_2004-2021.csv: season values used in our trend tests (columns: box, season, year, value, valid_days, days_in_season, coverage).
- published_sharma2023_tashkent_trends.csv: the only published second source we have (Tashkent only).

## Source of the NO2 numbers
NASA OMI/Aura OMNO2d v003 (cloud-screened tropospheric column, 0.25°), doi:10.5067/Aura/OMI/DATA3007, GES DISC. 2004-2020-05 via the open AWS copy (omi-no2-nasa.s3.amazonaws.com), 2020-06 onward via Earthdata Cloud OPeNDAP. Cross-checked against Giovanni for Tashkent (corr 0.99999999).

## Caveats
- Aura orbit drift after ~2020 is not corrected.
- Winter coverage is low (Tashkent ~35% of days).
- Box means are not city centres: each box covers ~165 km x 165 km.

## Other sites we can use (not downloaded here)
1. TROPOMI NO2 (Sentinel-5P), 2018 onward, 5.5x3.5 km: https://dataspace.copernicus.eu
2. NASA Giovanni: https://giovanni.gsfc.nasa.gov (OMNO2d, MODIS AOD, MERRA-2, no code needed)
3. MERRA-2 (PM2.5 reanalysis, 2D collections): https://disc.gsfc.nasa.gov
4. MODIS MAIAC AOD (MCD19A2): https://lpdaac.usgs.gov
5. SEDAC surface PM2.5 (van Donkelaar V5.GL): https://sedac.ciesin.columbia.edu
6. EDGAR emissions: https://edgar.jrc.ec.europa.eu
7. Uzhydromet (ground stations): https://hydromet.uz
8. Sharma et al. 2023: https://doi.org/10.1039/d2ea00075j
