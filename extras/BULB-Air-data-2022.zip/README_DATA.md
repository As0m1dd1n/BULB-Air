# BULB-Air data pack, year 2022 only (1 Jan – 31 Dec 2022)

Same structure as the 2004–2021 pack.

- omi_no2_daily_17boxes_2022.csv: daily tropospheric NO2 (10^15 molec/cm2), 6x6-cell (1.5°) box mean, 14 regions + 3 desert background boxes (bg_*). Empty = no valid retrieval.
- omi_no2_monthly_mean_2022.csv, omi_no2_monthly_valid_days_2022.csv: monthly means and the number of valid days behind them.
- omi_no2_annual_2022.csv: 2022 mean, valid days and coverage per box.
- omi_no2_seasonal_values_2022.csv: season values used in our trend tests. Winter 2022 (DJF) = Dec 2021 + Jan–Feb 2022.

Source: NASA OMI/Aura OMNO2d v003 (doi:10.5067/Aura/OMI/DATA3007), via NASA Earthdata Cloud OPeNDAP (2022 is after the AWS copy ends in May 2020). Cross-checked against Giovanni for Tashkent.
Caveats: Aura orbit drift after ~2020 is not corrected; winter coverage is low; boxes are ~165 km wide, not city centres.
No published second source covers 2022 (Sharma et al. 2023 ends in March 2021).
